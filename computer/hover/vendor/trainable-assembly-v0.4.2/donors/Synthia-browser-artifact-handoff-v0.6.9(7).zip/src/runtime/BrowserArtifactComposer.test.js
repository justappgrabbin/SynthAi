import test from 'node:test';
import assert from 'node:assert/strict';
import { access, readFile } from 'node:fs/promises';
import { AutoNovelExpressionPlanner } from './AutoNovelExpressionPlanner.js';
import { MessyExpressionRouter } from './MessyExpressionRouter.js';
import { BrowserArtifactComposer } from './BrowserArtifactComposer.js';

test('browser artifact upload request composes a grounded file through AutoNovel → MESSY', async () => {
  const composer = new BrowserArtifactComposer({ autoNovel: new AutoNovelExpressionPlanner(), messy: new MessyExpressionRouter() });
  const result = await composer.composeForPage({
    page: { forms: [{ fields: [{ name: 'portfolio', label: 'Upload portfolio', type: 'file', value: '' }] }] },
    message: 'I need to fill out this application',
    route: { task: 'form-workflow', dimension: 'BEING' },
    comprehension: { text: 'application' },
    profile: { portfolioFacts: ['Built a deterministic scene renderer', 'Implemented browser task continuation'] }
  });
  try {
    assert.equal(result.files.length, 1);
    const file = result.files[0];
    assert.equal(file.status, 'composed');
    assert.equal(file.expressionPlan.role, 'autonovel');
    assert.equal(file.expressionPlan.kind, 'browser-upload');
    assert.equal(file.morph.role, 'messy');
    assert.equal(file.morph.materializer, 'BrowserArtifactComposer');
    await access(file.filePath);
    const html = await readFile(file.filePath, 'utf8');
    assert.match(html, /deterministic scene renderer/);
    assert.match(html, /browser task continuation/);
  } finally {
    await composer.cleanup(result.tempDirs);
  }
});

test('browser artifact request remains unresolved without source evidence', async () => {
  const composer = new BrowserArtifactComposer({ autoNovel: new AutoNovelExpressionPlanner(), messy: new MessyExpressionRouter() });
  const result = await composer.composeForPage({
    page: { forms: [{ fields: [{ name: 'portfolio', label: 'Upload portfolio', type: 'file', value: '' }] }] },
    message: 'apply', route: { task: 'form-workflow' }, profile: {}
  });
  assert.equal(result.files.length, 0);
  assert.equal(result.fields[0].status, 'insufficient-evidence');
});
