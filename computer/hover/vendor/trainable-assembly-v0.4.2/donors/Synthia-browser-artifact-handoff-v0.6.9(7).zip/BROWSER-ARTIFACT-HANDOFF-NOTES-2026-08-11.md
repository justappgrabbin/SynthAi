# Synthia v0.6.9 — Browser ↔ AutoNovel/MESSY Artifact Handoff

## Added
- `BrowserArtifactComposer` detects upload fields (portfolio/resume/CV/attachment/work sample).
- For grounded artifact requests, AutoNovel creates the expression plan and MESSY selects the browser-artifact materializer.
- The composer emits a real local HTML artifact from supplied evidence only.
- Chrome DevTools executor uploads the actual file into a live `<input type=file>`.
- Existing page values are recognized by `BrowserTaskPlanner`, so uploaded file inputs are not overwritten or retyped.
- Missing evidence leaves an upload unresolved rather than fabricating content.

## Acceptance proof
Unknown site → `Apply With Portfolio` → application form → AutoNovel/MESSY generates portfolio HTML → CDP uploads real file → project summary generated from grounded facts → name/email filled → signature remains blank → no submission.

## Verification
- Artifact handoff smoke passes in real Chromium.
- `node --test`: 133 passed, 0 failed, 0 skipped.
