
## [0.1.0] - 2025-11-04

### First release