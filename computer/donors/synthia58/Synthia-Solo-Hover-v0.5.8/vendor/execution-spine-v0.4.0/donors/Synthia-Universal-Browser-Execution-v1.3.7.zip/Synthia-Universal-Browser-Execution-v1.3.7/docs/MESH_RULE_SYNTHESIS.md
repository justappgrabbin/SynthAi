# Mesh Rule Synthesis — v1.3.4

Execution loop:

1. Initial execution probe.
2. Parse/analyze artifact and derive behavioral/runtime requirements.
3. Capability gap becomes a mesh query, not an unhandled string.
4. Use the canonical gate's verified Fu Xi bits and Hamming distance to find topological anchors where addresses exist.
5. Combine that with semantic and graph-relation evidence.
6. Extract callable/AST payloads from neighboring capability nodes.
7. Monte-Carlo/stochastic candidate composition occurs over discovered mesh donors.
8. Compile/materialize candidate pure-JS behavior.
9. Probe candidate against the original execution contract.
10. AUTOLING/learned rule is registered back onto the mesh only after successful evidence.
11. Retry the original artifact.

Hard rules:

- No `targetGate & 0x3f` shortcut; `gateBits()` is canonical.
- No capability switch/case is used by `MeshRuleSynthesizer`.
- No separate capability lookup table is used by `RuntimeRulePlanner`; grammar capabilities are mesh nodes.
- Raw AST strings are not blindly pasted into arbitrary code positions.
- XOR is never treated as a generic mutation semantic.
- A generated candidate must be scored by execution progress/behavioral evidence before promotion.
