# Klein Contact Wiring — pure JavaScript

Runtime wiring added without changing the existing Kimi primitive/state-space vocabulary.

## Deep internal contact loop

`SynthiaAutomata.contact({ text, grammarB, ... })`

CHAT → DISEMINER → LANGUAGE CONTACT → HISTORICAL MONTE CARLO → AUTOLING → COMPUTATIONAL GRAMMAR CODER → CHAT

- DISEMINER observes/extracts meaning-bearing claims and relationships.
- Language Contact allows rule systems to borrow/adapt over contact generations.
- Historical Monte Carlo explores the contacted grammar's trajectory.
- AUTOLING learns from the observed signal and induces reusable rules from contacted forms.
- Computational Grammar Coder codes the signal into reusable computational grammar structure.
- Conversation is the surface; it receives the internal loop's result rather than replacing it.

## Public/person contact loop

`SynthiaAutomata.contact({ mode: 'public', partyA, partyB, grammarA, grammarB, ... })`

Person/agent addresses are exposed only through **Base**:

`PXXX.DIM#.G#.L#.C#.T#.B#`

Fields below Base (`D.M.S.A.Z.H`) are never returned by the public contact model.

## Canonical identity

Full internal canonical code remains:

`PXXX.DIM#.G#.L#.C#.T#.B#.D#.M#.S#.A#.Z#.H#`

The structured canonical-address object is preserved beside the compact code for computation; full names remain metadata, not identity.
